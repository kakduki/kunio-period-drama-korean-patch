# Patched ROM Report

## Candidate `softgate-0562f-tatsuichi`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_0562f_tatsuichi.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_0562f_tatsuichi.ips`
- Candidate MD5: `8bbe0f8b3ce78f37c9c77801993b72a4`
- Source: `たついち` / Tatsuichi
- Korean test string: `타츠이치`
- ROM offset: `0x0562F`
- PRG bank: `1`
- PRG offset: `0x0561F`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `90 92 82 91`
- New bytes: `89 98 8E 90`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-05643-heishichi`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_05643_heishichi.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_05643_heishichi.ips`
- Candidate MD5: `b5e1bfbf1df23204ff4821aa3c71f462`
- Source: `へいしち` / Heishichi
- Korean test string: `헤이시치`
- ROM offset: `0x05643`
- PRG bank: `1`
- PRG offset: `0x05633`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `9D 82 8C 91`
- New bytes: `8D 8E 8F 90`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-0561a-hashi`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_0561a_hashi.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_0561a_hashi.ips`
- Candidate MD5: `992f824025bf76ea4ab5272f760488ac`
- Source: `はし` / Hashi
- Korean test string: `다리`
- ROM offset: `0x0561A`
- PRG bank: `1`
- PRG offset: `0x0560A`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `96 88`
- New bytes: `8B 8C`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-0569d-hashi`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_0569d_hashi.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_0569d_hashi.ips`
- Candidate MD5: `4e561acffdd8231ee02bd02e75e178bd`
- Source: `はし` / Hashi
- Korean test string: `다리`
- ROM offset: `0x0569D`
- PRG bank: `1`
- PRG offset: `0x0568D`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `A0 92`
- New bytes: `8B 8C`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-056da-hashi`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_056da_hashi.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_056da_hashi.ips`
- Candidate MD5: `fc23c51af65e0833c7c693a9b20ebe5a`
- Source: `はし` / Hashi
- Korean test string: `다리`
- ROM offset: `0x056DA`
- PRG bank: `1`
- PRG offset: `0x056CA`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `9A 8C`
- New bytes: `8B 8C`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-0571c-hashi`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_0571c_hashi.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_0571c_hashi.ips`
- Candidate MD5: `2ab2df9debb2294bbbdaa78e071a873a`
- Source: `はし` / Hashi
- Korean test string: `다리`
- ROM offset: `0x0571C`
- PRG bank: `1`
- PRG offset: `0x0570C`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `92 84`
- New bytes: `8B 8C`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-057d4-hashi`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_057d4_hashi.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_057d4_hashi.ips`
- Candidate MD5: `52df851d41731c9d4fce9b497f73bbee`
- Source: `はし` / Hashi
- Korean test string: `다리`
- ROM offset: `0x057D4`
- PRG bank: `1`
- PRG offset: `0x057C4`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `A6 98`
- New bytes: `8B 8C`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-0736a-raifu`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_0736a_raifu.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_0736a_raifu.ips`
- Candidate MD5: `28aea3f00214fc3caec56c7cc2e553f8`
- Source: `ライフ` / Raifu
- Korean test string: `라이프`
- ROM offset: `0x0736A`
- PRG bank: `1`
- PRG offset: `0x0735A`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `BB 95 AF`
- New bytes: `96 8E 97`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-0739d-raifu`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_0739d_raifu.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_0739d_raifu.ips`
- Candidate MD5: `ad1534d9a2c5895af372c21698fa9a93`
- Source: `ライフ` / Raifu
- Korean test string: `라이프`
- ROM offset: `0x0739D`
- PRG bank: `1`
- PRG offset: `0x0738D`
- Screen/context: `fceux_input_explorer_v042 frame 883 dialogue screen`
- Old bytes: `BB 95 AF`
- New bytes: `96 8E 97`
- Patch classification: `PASS`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until the exact string is visually confirmed on a release/high-risk pass.
- Failure class: `none`
- Failure reason: `none`

## Candidate `softgate-dev-combined`

- Build status: `PASS`
- Base ROM: `rom/Kunio Kun no Jidaigeki Dayo Zenin Shuugou! (J).nes`
- Base MD5: `0d406a85285b4de8468f0dab6aad5fe5`
- Candidate ROM: `output/kunio_period_drama_softgate_dev_combined.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_dev_combined.ips`
- Candidate MD5: `4905417f129726394941bed079c2e848`
- Applied strings: `9`
- Boot smoke classification: `PASS`
- Visual classification: `UNKNOWN` until release/high-risk manual visual review.
- Failure class: `none`
- Failure reason: `none`

| ROM offset | source | Korean | romaji | old bytes | new bytes |
| --- | --- | --- | --- | --- | --- |
| `0x0562F` | `たついち` | `타츠이치` | Tatsuichi | `90 92 82 91` | `89 98 8E 90` |
| `0x05643` | `へいしち` | `헤이시치` | Heishichi | `9D 82 8C 91` | `8D 8E 8F 90` |
| `0x0561A` | `はし` | `다리` | Hashi | `96 88` | `8B 8C` |
| `0x0569D` | `はし` | `다리` | Hashi | `A0 92` | `8B 8C` |
| `0x056DA` | `はし` | `다리` | Hashi | `9A 8C` | `8B 8C` |
| `0x0571C` | `はし` | `다리` | Hashi | `92 84` | `8B 8C` |
| `0x057D4` | `はし` | `다리` | Hashi | `A6 98` | `8B 8C` |
| `0x0736A` | `ライフ` | `라이프` | Raifu | `BB 95 AF` | `96 8E 97` |
| `0x0739D` | `ライフ` | `라이프` | Raifu | `BB 95 AF` | `96 8E 97` |

## Quarantined High-Risk Candidates

These candidates are built as isolated ROM/IPS outputs only. They are not included in the cumulative dev candidate until visual proof is collected in the correct screen context.

### Candidate `softgate-quarantine-05644-katana`

- Build status: `PASS`
- Risk class: `HIGH_RISK_OVERLAPS_SELECTED_DEV_SPAN`
- Candidate ROM: `output/kunio_period_drama_softgate_quarantine_05644_katana.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_quarantine_05644_katana.ips`
- Candidate MD5: `479c54ff09a4b6ecef6586682709f2fb`
- Source: `カタナ` / Katana
- Korean test string: `카타나`
- ROM offset: `0x05644`
- PRG bank: `1`
- Old bytes: `82 8C 91`
- New bytes: `88 89 8A`
- Boot smoke classification: `PASS`
- Visual classification: `HIGH_RISK_UNKNOWN` until Katana is visible on the item-list screen.
- Combined dev inclusion: `no`

### Candidate `softgate-quarantine-06295-katana`

- Build status: `PASS`
- Risk class: `HIGH_RISK_VISUAL_CONTEXT_PENDING`
- Candidate ROM: `output/kunio_period_drama_softgate_quarantine_06295_katana.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_quarantine_06295_katana.ips`
- Candidate MD5: `41f9cd98e62e05901f20b15ae0b0836e`
- Source: `カタナ` / Katana
- Korean test string: `카타나`
- ROM offset: `0x06295`
- PRG bank: `1`
- Old bytes: `82 8C 91`
- New bytes: `88 89 8A`
- Boot smoke classification: `PASS`
- Visual classification: `HIGH_RISK_UNKNOWN` until Katana is visible on the item-list screen.
- Combined dev inclusion: `no`

### Candidate `softgate-quarantine-0631c-katana`

- Build status: `PASS`
- Risk class: `HIGH_RISK_VISUAL_CONTEXT_PENDING`
- Candidate ROM: `output/kunio_period_drama_softgate_quarantine_0631c_katana.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_quarantine_0631c_katana.ips`
- Candidate MD5: `b4870e6f6e7fff1afe1d924128424237`
- Source: `カタナ` / Katana
- Korean test string: `카타나`
- ROM offset: `0x0631C`
- PRG bank: `1`
- Old bytes: `82 8C 91`
- New bytes: `88 89 8A`
- Boot smoke classification: `PASS`
- Visual classification: `HIGH_RISK_UNKNOWN` until Katana is visible on the item-list screen.
- Combined dev inclusion: `no`

### Candidate `softgate-quarantine-0635a-katana`

- Build status: `PASS`
- Risk class: `HIGH_RISK_VISUAL_CONTEXT_PENDING`
- Candidate ROM: `output/kunio_period_drama_softgate_quarantine_0635a_katana.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_quarantine_0635a_katana.ips`
- Candidate MD5: `71194a85b30ed5c06ca6f5afbb6f310b`
- Source: `カタナ` / Katana
- Korean test string: `카타나`
- ROM offset: `0x0635A`
- PRG bank: `1`
- Old bytes: `82 8C 91`
- New bytes: `88 89 8A`
- Boot smoke classification: `PASS`
- Visual classification: `HIGH_RISK_UNKNOWN` until Katana is visible on the item-list screen.
- Combined dev inclusion: `no`

### Candidate `softgate-quarantine-07227-katana`

- Build status: `PASS`
- Risk class: `HIGH_RISK_VISUAL_CONTEXT_PENDING`
- Candidate ROM: `output/kunio_period_drama_softgate_quarantine_07227_katana.nes`
- Candidate IPS: `output/kunio_period_drama_softgate_quarantine_07227_katana.ips`
- Candidate MD5: `dfd1888d4cad7f443d168318cd7e0ae5`
- Source: `カタナ` / Katana
- Korean test string: `카타나`
- ROM offset: `0x07227`
- PRG bank: `1`
- Old bytes: `8A 94 99`
- New bytes: `88 89 8A`
- Boot smoke classification: `PASS`
- Visual classification: `HIGH_RISK_UNKNOWN` until Katana is visible on the item-list screen.
- Combined dev inclusion: `no`


